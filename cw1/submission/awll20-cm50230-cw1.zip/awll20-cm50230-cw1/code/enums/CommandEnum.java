package teamd.cw1.enums;

public enum CommandEnum {
	DISTANCE,
    INTERVAL_REACHED,
    TOUCH_CONTACT
}
