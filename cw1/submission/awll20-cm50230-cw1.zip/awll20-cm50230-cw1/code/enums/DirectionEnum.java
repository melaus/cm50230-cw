package teamd.cw1.enums;

public enum DirectionEnum {
	FRONT,
	LEFT,
	RIGHT
}
