package teamd.cw1.enums;

public enum StatusEnum {
	FINDING_WALL,
	FOLLOWING_WALL,
	LOOKING_FORWARD
}
